
<!-- Main.blade.php -->
<?php $__env->startSection('site-content'); ?>
<center>
    <p>Welcome Admin,

        <?php if(session()->has('userdata')): ?>
            <b><?php echo e(ucfirst(session()->get('userdata')->name)); ?></b>
            (
            <b><?php echo e(session()->get('userdata')->email); ?></b>
            )
        <?php endif; ?>
        <hr />
    </p>
    <?php echo $__env->make('dashboard.layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('admin-content'); ?>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\ActivityTracker\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>