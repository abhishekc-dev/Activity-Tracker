<nav>
    <ul>
        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>

        <?php if(!session()->has('userdata')): ?>
            <li><a href="<?php echo e(url('register')); ?>">Register</a></li>
        <?php endif; ?>

        <?php if(!session()->has('userdata')): ?>
            <li><a href="<?php echo e(url('login')); ?>">Login</a></li>
        <?php else: ?>
            <li><a href="<?php echo e(url('user/logout')); ?>">Logout</a></li>
        <?php endif; ?>

        <li><a href="<?php echo e(url('about')); ?>">About Software</a></li>
        <li><a href="<?php echo e(url('license')); ?>">License</a></li>
        <li><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
    </ul>
</nav><?php /**PATH C:\xampp\htdocs\laravel-project\ActivityTracker\resources\views/layouts/nav.blade.php ENDPATH**/ ?>