;


<?php $__env->startSection('internal-style'); ?>
<style>
table {
    width: 100%;
    border-collapse: collapse;
}

th,
td {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

th {
    background-color: #f2f2f2;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
<h3>
    Manage Team for the Project |
    <a href="<?php echo e(url('admin/manage-team/add')); ?>">
        <button>
            Create New Team
        </button>
    </a>
</h3>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Team Name</th>
            <th>Project Name</th>
            <th>Member Name</th>
            <th>Member Type</th>
            <th>Is Active</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>1</td>
            <td>Development Team</td>
            <td>101</td>
            <td>1001</td>
            <td>manager</td>
            <td>yes</td>
            <td>Edit</td>
            <td>Delete</td>
        </tr>

    </tbody>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\ActivityTracker\resources\views/admin/team/show.blade.php ENDPATH**/ ?>