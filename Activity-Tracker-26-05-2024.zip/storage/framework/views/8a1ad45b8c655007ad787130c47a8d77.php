;

<?php $__env->startSection('site-content'); ?>
<center>
    <form action="<?php echo e(url('user/save')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <p>User Register</p>
        <p>Enter Name :<input type="text" name="name" required></p>
        <p>Enter Email :<input type="email" name="email" required></p>
        <p>Enter Password :<input type="password" name="password" required></p>
        <p>Enter mobile :<input type="tel" name="mobile" required></p>
        <p>Select Designation :
            <select name="designation" required>
                <option value="">--select--</option>
                <?php if(count($roles) > 0): ?>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option><?php echo e($role->designations); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </p>
        <p><input type="submit" name="submit" value="register" /></p>
    </form>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\ActivityTracker\resources\views/user/register.blade.php ENDPATH**/ ?>