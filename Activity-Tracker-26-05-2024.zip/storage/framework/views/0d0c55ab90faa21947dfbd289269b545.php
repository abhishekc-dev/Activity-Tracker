;

<?php $__env->startSection('admin-content'); ?>
<b>Edit Role</b>
<a href="<?php echo e(url('admin/manage-role/add')); ?>">
    <a href="<?php echo e(url('admin/manage-role')); ?>">Back</a>
</a>
<form method="POST" action="<?php echo e(url('admin/manage-role/update/' . $role->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <p>Enter Designation :
        <input type="text" name="designation" value="<?php echo e($role->designations); ?>" required>
        <input type="submit" name="submit" value="Update" />
    </p>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\ActivityTracker\resources\views/admin/role/edit.blade.php ENDPATH**/ ?>