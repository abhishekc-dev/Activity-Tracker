@extends('master');

@section('site-content')
<center>
    <form action="{{url('user/save')}}" method="POST">
        @csrf
        <p>User Register</p>
        <p>Enter Name :<input type="text" name="name" required></p>
        <p>Enter Email :<input type="email" name="email" required></p>
        <p>Enter Password :<input type="password" name="password" required></p>
        <p>Enter mobile :<input type="tel" name="mobile" required></p>
        <p>Select Designation :
            <select name="designation" required>
                <option value="">--select--</option>
                @if (count($roles) > 0)
                @foreach ($roles as $role)
                <option>{{$role->designations}}</option>
                @endforeach ($roles as $role)
                @endif
            </select>
        </p>
        <p><input type="submit" name="submit" value="register" /></p>
    </form>
</center>
@endsection