@extends('master')

@section('site-content')
<div class="content">
    <h1>Activity Tracker Management Tool</h1>
    <p>Modern Task Need Modern Solution</p>
</div>
@endsection