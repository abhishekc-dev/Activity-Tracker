<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="{{ asset('assets/css/master-style.css') }}" />
    <title>My Website</title>
    <style>

    </style>
    @yield('internal-style');
</head>

<body>

    <!-- Nav Includes start -->
    @include('layouts.nav')
    <!-- Nav Includes End -->

    <div class="container-wrapper">
        <!-- Content Section start-->
        @yield('site-content')
        <!-- Content Section End-->
    </div>

    <!-- Footer Includes start -->
    @include('layouts.footer')
    <!-- Footer Includes End -->

</body>

</html>