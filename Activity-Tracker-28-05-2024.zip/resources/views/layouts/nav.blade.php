<nav>
    <ul>
        <li><a href="{{url('/')}}">Home</a></li>

        @if(!session()->has('userdata'))
            <li><a href="{{url('register')}}">Register</a></li>
        @endif

        @if(!session()->has('userdata'))
            <li><a href="{{url('login')}}">Login</a></li>
        @else
            <li><a href="{{url('user/logout')}}">Logout</a></li>
        @endif

        <li><a href="{{url('about')}}">About Software</a></li>
        <li><a href="{{url('license')}}">License</a></li>
        <li><a href="{{url('contact')}}">Contact</a></li>
    </ul>
</nav>