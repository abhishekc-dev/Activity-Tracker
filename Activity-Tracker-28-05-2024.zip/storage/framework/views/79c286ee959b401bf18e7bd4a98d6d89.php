<!-- For Admin Navigation start -->
<nav>
    <ul>
        <li><a href="<?php echo e(url('/admin/manage-project/')); ?>"
                style="<?php echo e(request()->segment(2) == 'manage-project' ? 'text-decoration:underline overline' : ''); ?>">Manage
                Project</a></li>
        <li><a href="<?php echo e(url('/admin/manage-role/')); ?>"
                style="<?php echo e(request()->segment(2) == 'manage-role' ? 'text-decoration:underline overline' : ''); ?>">Manage
                Role</a></li>
        <li><a href="<?php echo e(url('/admin/manage-team/')); ?>"
                style="<?php echo e(request()->segment(2) == 'manage-team' ? 'text-decoration:underline overline' : ''); ?>">Manage
                Team</a>
        </li>
        <li><a href="<?php echo e(url('/admin/manage-resource/')); ?>"
                style="<?php echo e(request()->segment(2) == 'manage-resource' ? 'text-decoration:underline overline' : ''); ?>">Manage
                Resource</a></li>
        <li><a href="<?php echo e(url('/admin/manage-task/')); ?>"
                style="<?php echo e(request()->segment(2) == 'manage-task' ? 'text-decoration:underline overline' : ''); ?>">Manage
                Task</a></li>
    </ul>
</nav>
`
<!-- For Admin Navigation End--><?php /**PATH C:\xampp\htdocs\laravel-project\ActivityTracker\resources\views/dashboard/layouts/nav.blade.php ENDPATH**/ ?>