;


<?php $__env->startSection('internal-style'); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<style>
table {
    width: 50%;
    border-collapse: collapse;
}

th,
td {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

th {
    background-color: #f2f2f2;
}

.formcontrol {
    width: 100%;
}

.badge {
    display: inline-block;
    padding: 5px;
    font-size: 10px;
    color: #fff;
    font-weight: bold;
    background-color: grey;
    border-radius: 5px;
    text-align: center;
    font-family: Arial, sans-serif;
    margin: 5px;
}

.loader {
    display: flex;
    justify-content: center;
    align-items: center;
    height: auto;
    margin: 0px auto;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
<h3>
    Edit Member of Team |
    <a href="<?php echo e(url('admin/manage-team')); ?>">
        <button>
            back
        </button>
    </a>
</h3>
<form action="<?php echo e(url('admin/manage-team/update/'.$selectedProject->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <table>
        <tr>
            <th>Select Project</th>
            <td>
                <select class="formcontrol" onchange="handleAjaxProjectForm(this.value);" name="project_id"
                    id="project_id">
                    <option value="">Select Project </option>
                    <?php if(count($projects) > 0): ?>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($project->id); ?>" <?php if($selectedProject->id == $project->id): ?> <?php echo e("selected"); ?> <?php endif; ?>>
                        <?php echo e($project->project_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            </td>
        </tr>
        <script>
        function handleAjaxProjectForm(project_id) {
            if (project_id.trim() == "") {
                window.alert('Please Select Some Project');
            }

            document.querySelector("#ajax_project_form").innerHTML = `<div class="loader">
    <i class="fas fa-spinner fa-spin fa-3x"></i>
  </div>`;

            let api = fetch(`<?php echo e(url('api/ajax/project_listing/edit/')); ?>/${project_id}`, {
                headers: {
                    "Content-Type": "application/json;charset=utf-8"
                }
            }).then((response) => {
                if (response.ok) {
                    return response.json();
                } else {
                    throw new Error('Api Error');
                }
            }).then((result) => {
                if (result.code == 200 && result.status == true) {
                    setTimeout(() => {
                        document.querySelector("#ajax_project_form").innerHTML = result.data.html;
                    }, 2000);
                }
            }).catch((error) => {
                console.log('error', error);
            })



        }
        //Once All the Elements are Rendered Then Only Execute
        document.addEventListener('DOMContentLoaded', function() {
            if (document.querySelector("#project_id")) {
                let projectID = document.querySelector("#project_id").value;
                handleAjaxProjectForm(projectID);
            }
        });
        </script>
        <tbody id="ajax_project_form">

        </tbody>

    </table>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\ActivityTracker\resources\views/admin/team/edit.blade.php ENDPATH**/ ?>