<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/css/master-style.css')); ?>" />
    <title>My Website</title>
    <style>

    </style>
    <?php echo $__env->yieldContent('internal-style'); ?>;
</head>

<body>

    <!-- Nav Includes start -->
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Nav Includes End -->

    <div class="container-wrapper">
        <!-- Content Section start-->
        <?php echo $__env->yieldContent('site-content'); ?>
        <!-- Content Section End-->
    </div>

    <!-- Footer Includes start -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer Includes End -->

</body>

</html><?php /**PATH C:\xampp\htdocs\laravel-project\ActivityTracker\resources\views/master.blade.php ENDPATH**/ ?>