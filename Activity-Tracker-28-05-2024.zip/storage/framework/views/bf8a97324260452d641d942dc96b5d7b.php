;

<?php $__env->startSection('site-content'); ?>
<center>
    <form action="<?php echo e(url('user/login')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <p>User Login</p>
        <p>Enter Email :<input type="email" name="email" required></p>
        <p>Enter Password :<input type="password" name="password" required></p>
        <p><input type="submit" name="submit" value="Login" /></p>
    </form>
</center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\ActivityTracker\resources\views/pages/login.blade.php ENDPATH**/ ?>