@extends('master');

@section('site-content')
<center>
    <form action="{{url('user/login')}}" method="POST">
        @csrf
        <p>User Login</p>
        <p>Enter Email :<input type="email" name="email" required></p>
        <p>Enter Password :<input type="password" name="password" required></p>
        <p><input type="submit" name="submit" value="Login" /></p>
    </form>
</center>
@endsection