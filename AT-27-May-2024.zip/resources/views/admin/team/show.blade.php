@extends('dashboard.admin')

@section('internal-style')
<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }

    th,
    td {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }

    th {
        background-color: #f2f2f2;
    }

    tr:nth-child(even) {
        background-color: lightgrey;
    }

    #teamTable tr {
        background-color: white;
    }

    #teamTable th {
        background-color: black;
        color: white;
    }

    /* Add transition classes */
    .teamInfoHidden {
        display: none;
        height: 0;
        overflow: hidden;
        transition: height 0.3s ease, opacity 0.3s ease;
    }

    .teamInfoVisible {
        display: table-row;
        height: auto;
        transition: height 0.3s ease, opacity 0.3s ease;
    }

    .teamInfoRow {
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .teamInfoVisible .teamInfoRow {
        opacity: 1;
    }

    .edit-btn,
    .delete-btn {
        cursor: pointer;
        font-size: 16px;
    }

    .edit-btn {
        color: blue;
    }

    .delete-btn {
        color: red;
    }
</style>
@endsection

@section('admin-content')
<h3>
    Manage Team for the Project |
    <a href="{{url('admin/manage-team/add')}}">
        <button>
            Create New Team
        </button>
    </a>
</h3>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Project Name</th>
            <th>Manager Name</th>
            <th>No of Member(s)</th>
            <th>Assigned Team</th>
            <th>View Team</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        @if (count($projects) > 0)
            @foreach ($projects as $project)
                <tr>
                    <td>{{$project->id}}</td>
                    <td><a href="#">
                            {{$project->project_name}}
                        </a><br />
                        @php
                            $colors = [
                                'High' => 'display:inline-block;padding:4px;color:red;background:pink;border-radius:5px;',
                                'Medium' => 'display:inline-block;padding:5px;color:green;background:lightgreen;border-radius:5px;',
                                'Low' => 'display:inline-block;padding:5px;color:blue;background:skyblue;border-radius:5px;',
                            ];
                            $style = $colors[$project->priority]
                        @endphp
                        <span style="{!!$style!!}">{{$project->priority}}</span>
                        | <b>{{$project->status}}</b>|<i> {{$project->contract_type}} </i>
                    </td>
                    <td>
                        <b>
                            {{ProjectHelper::getManagerInfo($project->user_id)->name}}
                        </b>
                        <br />
                        <i>
                            <a href="mailto:{{ProjectHelper::getManagerInfo($project->user_id)->email}}">
                                {{ProjectHelper::getManagerInfo($project->user_id)->email}}
                            </a>
                        </i>
                    </td>
                    <td>{{$project->team_size}} Member(s)</td>
                    <td>{{$project->id}}</td>
                    <td style="cursor:pointer" onclick="toggleTeamInfo({{$project->id}})">
                        <center>
                            @php
                                $isVisible = ProjectHelper::getTeamName($project->id) ? true : false;
                            @endphp
                            @if ($isVisible)
                                <img src="{{asset('assets/images/view-icons.png')}}" style="height:40px;width:40px;">
                            @else
                                No Team Assigned
                            @endif
                        </center>
                    </td>
                    <td class="edit-btn" onclick="editProject({{$project->id}})">✏️</td>
                    <td class="delete-btn" onclick="deleteProject({{$project->id}})">🗑️</td>
                </tr>
                @if (ProjectHelper::getTeamName($project->id))
                    <tr id="teamInfoTR{{$project->id}}" class="teamInfoHidden">
                        <th>Team Name</th>
                        <td>
                            {{ProjectHelper::getTeamName($project->id)->team_name}}
                        </td>
                        <td colspan="8">
                            <div class="teamInfoRow">
                                <table border="1" id="teamTable">
                                    <tr>
                                        <th>Team ID (#)</th>
                                        <th>Member Name</th>
                                        <th>Member Type</th>
                                        <th>Status</th>
                                    </tr>
                                    @if (count(ProjectHelper::getTeamsInfo($project->id)) > 0)
                                        @foreach (ProjectHelper::getTeamsInfo($project->id) as $team)
                                            <tr>
                                                <td>{{$team->id}}</td>
                                                <td>{{ProjectHelper::getUserInfo($team->user_id)->name}}</td>
                                                <td>{{$team->member_type}}</td>
                                                <td>{{$team->is_active}}</td>
                                            </tr>
                                        @endforeach
                                    @endif
                                </table>
                            </div>
                        </td>
                    </tr>
                @endif
            @endforeach
        @else
            <tr>
                <td colspan="8" style="text-align:center">No Record Found</td>
            </tr>
        @endif
    </tbody>
</table>

<script>
    function toggleTeamInfo(id) {
        var row = document.getElementById('teamInfoTR' + id);
        if (row.classList.contains('teamInfoHidden')) {
            row.classList.remove('teamInfoHidden');
            row.classList.add('teamInfoVisible');
        } else {
            row.classList.remove('teamInfoVisible');
            row.classList.add('teamInfoHidden');
        }
    }

    function editProject(id) {
        // Add your edit project logic here
        alert('Edit project with ID ' + id);
    }

    function deleteProject(id) {
        // Add your delete project logic here
        alert('Delete project with ID ' + id);
    }
</script>

@endsection