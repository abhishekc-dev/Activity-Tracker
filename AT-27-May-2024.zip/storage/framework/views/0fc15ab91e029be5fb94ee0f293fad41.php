

<?php $__env->startSection('internal-style'); ?>
<style>
table {
    width: 100%;
    border-collapse: collapse;
}

th,
td {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
}

th {
    background-color: #f2f2f2;
}

tr:nth-child(even) {
    background-color: lightgrey;
}

#teamTable tr {
    background-color: white;
}

#teamTable th {
    background-color: black;
    color: white;
}

/* Add transition classes */
.teamInfoHidden {
    display: none;
    height: 0;
    overflow: hidden;
    transition: height 0.3s ease, opacity 0.3s ease;
}

.teamInfoVisible {
    display: table-row;
    height: auto;
    transition: height 0.3s ease, opacity 0.3s ease;
}

.teamInfoRow {
    opacity: 0;
    transition: opacity 0.3s ease;
}

.teamInfoVisible .teamInfoRow {
    opacity: 1;
}

.edit-btn,
.delete-btn {
    cursor: pointer;
    font-size: 16px;
}

.edit-btn {
    color: blue;
}

.delete-btn {
    color: red;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
<h3>
    Manage Team for the Project |
    <a href="<?php echo e(url('admin/manage-team/add')); ?>">
        <button>
            Create New Team
        </button>
    </a>
</h3>
<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Project Name</th>
            <th>Manager Name</th>
            <th>No of Member(s)</th>
            <th>Assigned Team</th>
            <th>View Team</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php if(count($projects) > 0): ?>
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($project->id); ?></td>
            <td><a href="#">
                    <?php echo e($project->project_name); ?>

                </a><br />
                <?php
                $colors = [
                'High' => 'display:inline-block;padding:4px;color:red;background:pink;border-radius:5px;',
                'Medium' => 'display:inline-block;padding:5px;color:green;background:lightgreen;border-radius:5px;',
                'Low' => 'display:inline-block;padding:5px;color:blue;background:skyblue;border-radius:5px;',
                ];
                $style = $colors[$project->priority]
                ?>
                <span style="<?php echo $style; ?>"><?php echo e($project->priority); ?></span>
                | <b><?php echo e($project->status); ?></b>|<i> <?php echo e($project->contract_type); ?> </i>
            </td>
            <td>
                <b>
                    <?php echo e(ProjectHelper::getManagerInfo($project->user_id)->name); ?>

                </b>
                <br />
                <i>
                    <a href="mailto:<?php echo e(ProjectHelper::getManagerInfo($project->user_id)->email); ?>">
                        <?php echo e(ProjectHelper::getManagerInfo($project->user_id)->email); ?>

                    </a>
                </i>
            </td>
            <td><?php echo e($project->team_size); ?> Member(s)</td>
            <td><?php echo e($project->id); ?></td>
            <td style="cursor:pointer" onclick="toggleTeamInfo(<?php echo e($project->id); ?>)">
                <center>
                    <?php
                    $isVisible = ProjectHelper::getTeamName($project->id) ? true : false;
                    ?>
                    <?php if($isVisible): ?>
                    <img src="<?php echo e(asset('assets/images/view-icons.png')); ?>" style="height:40px;width:40px;">
                    <?php else: ?>
                    No Team Assigned
                    <?php endif; ?>
                </center>
            </td>
            <td class="edit-btn" onclick="editProject(<?php echo e($project->id); ?>)">✏️</td>
            <td class="delete-btn" onclick="deleteProject(<?php echo e($project->id); ?>)">🗑️</td>
        </tr>
        <?php if(ProjectHelper::getTeamName($project->id)): ?>
        <tr id="teamInfoTR<?php echo e($project->id); ?>" class="teamInfoHidden">
            <th>Team Name</th>
            <td>
                <?php echo e(ProjectHelper::getTeamName($project->id)->team_name); ?>

            </td>
            <td colspan="8">
                <div class="teamInfoRow">
                    <table border="1" id="teamTable">
                        <tr>
                            <th>Team ID (#)</th>
                            <th>Member Name</th>
                            <th>Member Type</th>
                            <th>Status</th>
                        </tr>
                        <?php if(count(ProjectHelper::getTeamsInfo($project->id)) > 0): ?>
                        <?php $__currentLoopData = ProjectHelper::getTeamsInfo($project->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($team->id); ?></td>
                            <td><?php echo e(ProjectHelper::getUserInfo($team->user_id)->name); ?></td>
                            <td><?php echo e($team->member_type); ?></td>
                            <td><?php echo e($team->is_active); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </table>
                </div>
            </td>
        </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
            <td colspan="8" style="text-align:center">No Record Found</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

<script>
function toggleTeamInfo(id) {
    var row = document.getElementById('teamInfoTR' + id);
    if (row.classList.contains('teamInfoHidden')) {
        row.classList.remove('teamInfoHidden');
        row.classList.add('teamInfoVisible');
    } else {
        row.classList.remove('teamInfoVisible');
        row.classList.add('teamInfoHidden');
    }
}

function editProject(id) {
    // Add your edit project logic here
    alert('Edit project with ID ' + id);
}

function deleteProject(id) {
    // Add your delete project logic here
    alert('Delete project with ID ' + id);
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\ActivityTracker\resources\views/admin/team/show.blade.php ENDPATH**/ ?>