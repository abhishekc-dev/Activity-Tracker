;

<?php $__env->startSection('admin-content'); ?>
<b>Add Role</b>
<a href="<?php echo e(url('admin/manage-role/add')); ?>">
    <a href="<?php echo e(url('admin/manage-role')); ?>">Back</a>
</a>
<form method="POST" action="<?php echo e(url('admin/manage-role/add')); ?>">
    <?php echo csrf_field(); ?>
    <p>Enter Designation :
        <input type="text" name="designation" required>
        <input type="submit" name="submit" value="Add" />
    </p>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\ActivityTracker\resources\views/admin/role/add.blade.php ENDPATH**/ ?>