<?php $__env->startSection('site-content'); ?>
<div class="content">
    <h1>Activity Tracker Management Tool</h1>
    <p>Modern Task Need Modern Solution</p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel-project\ActivityTracker\resources\views/pages/home.blade.php ENDPATH**/ ?>